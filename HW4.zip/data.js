module.exports = {
    comments: [],//List of dictionarys with name and comment of person
    images: [],
    xsrfToken: "",
    bufferData: Buffer.from([]),
    dataLength: 0,
    isBuffering: false,
    headerLength: 0,
    clients: [],
    cookiesVisits: []//List of dicts with ID to the number of
}
