module.exports = {
    200: "HTTP/1.1 200 OK ",
    301: "HTTP/1.1 301 Moved Permanently ",
    404: "HTTP/1.1 404 Not Found ",
    101: "HTTP/1.1 101 Switching Protocols "
};